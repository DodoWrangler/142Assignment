// APSC 142 Engineering Programming Project Starter Code
// Copyright Sean Kauffman 2024

#include <stdlib.h>
#include <stdio.h>
#include "defines.h"
#include "colours.h"
#include "map.h"
#include <string.h>

extern char *map, *dot_map;
extern int width, height;

int move_actor(int * y, int * x, char direction, int eat_dots) {
//I switched the order so that off map is checked first
    if (direction == LEFT) {
        //check if it is off map
        if ((*x - 1) < 0) {
            return MOVED_INVALID_DIRECTION;
        } else if (is_wall(*y, *x - 1) == WALL) {
            return MOVED_INVALID_DIRECTION;
            //check if it is moving into a wall
        } else if (is_wall(*y, *x - 1) == NOT_WALL) {
            //it is not, so we are changing the coords
            *x = *x - 1;
            //we check if we are eating a dot
            if (eat_dots == 1) {
                //replace dot with blank
                map[((*y) * width) + *x ] = EMPTY;
                dot_map[((*y) * width) + *x] = EMPTY;
            }
        }
    } else if (direction == DOWN) {
        //check if it is off map
        if (8 < (*y + 1)) {
            return MOVED_INVALID_DIRECTION;
        } else if (is_wall(*y + 1, *x) == WALL) {
            return MOVED_INVALID_DIRECTION;
            //check if it is moving into a wall
        } else if (is_wall(*y + 1, *x) == NOT_WALL) {
            //it is not, so we are changing the coords
            *y = *y + 1;
            //we check if we are eating a dot
            if (eat_dots == 1) {
                //replace dot with blank
                map[((*y) * width) + *x] = EMPTY;
                dot_map[((*y) * width) + *x] = EMPTY;
            }
        }
    } else if (direction == RIGHT) {
        //check if it is off map
        if (8 < (*x + 1)) {
            return MOVED_INVALID_DIRECTION;
        } else if (is_wall(*y, *x + 1) == WALL) {
            return MOVED_INVALID_DIRECTION;
            //check if it is moving into a wall
        } else if (is_wall(*y, *x + 1) == NOT_WALL) {
            //it is not, so we are changing the coords
            *x = *x + 1;
            //we check if we are eating a dot
            if (eat_dots == 1) {
                //replace dot with blank
                map[((*y) * width) + *x] = EMPTY;
                dot_map[((*y) * width) + *x] = EMPTY;
            }
        }
    } else if (direction == UP) {
        //check if it is moving into a wall
        if ((*y - 1) < 0) {
            return MOVED_INVALID_DIRECTION;
        } else if (is_wall(*y - 1, *x) == WALL) {
            return MOVED_INVALID_DIRECTION;//check if it is off map
        } else if (is_wall(*y - 1, *x) == NOT_WALL) {
            //it is not, so we are changing the coords
            *y = *y - 1;
            //we check if we are eating a dot
            if (eat_dots == 1) {
                //replace dot with blank
//                map[((*y) * width) + *x] = EMPTY;
                dot_map[((*y) * width) + *x] = EMPTY;
            }
        }
    } else {
        return MOVED_INVALID_DIRECTION;
    }
    return MOVED_OKAY;
}


int is_wall(int y, int x) {
    //if it is a wall
    if (map[(y * width) + x] == 'W') {
        return WALL;
    }
    return NOT_WALL;
}

//MAKE
char *load_map(char *filename, int *map_height, int *map_width) {
    FILE *fp;
    fp = fopen(filename, "r");
    map = (char *) malloc((*map_height * *map_width) * sizeof(char *) + sizeof(char *));
    for (int i = 0; i <= *map_height**map_width-1; ++i) {
        fscanf(fp, "%c  ", &map[i]);
    }
    map[(*map_width * *map_height)] = '\0';
    fclose(fp);
    return map;
}

void print_map(char* mapArray, int* mapHeight, int* mapWidth){
    //changes to wall colour
    change_text_colour(BLUE);
    //prints top map cap
    //extra "\n" to debug clion
    printf("W W W W W W W W W W W\n");
    //prints body of map, first for loop cycles through each row
    for(int i=0; i<=*mapHeight-1; i++){
        //prints left wall
        change_text_colour(BLUE);
        printf("W ");
        //prints each column entry of current row
        for (int j=0; j<*mapWidth; j++){
            //color shifts depending on the character about to be printed

            //creates temporary character tracker. Makes it easier for me to come in and change things :)
            char nextPrint = mapArray[((*mapHeight)*(i))+(j)];
            if(nextPrint == '.'){
            change_text_colour(WHITE);
            } else if(nextPrint == 'G'){
                change_text_colour(PINK);
            } else if(nextPrint == 'P'){
                change_text_colour(YELLOW);
            }else{
                change_text_colour(BLUE);
            }
            printf("%c ", nextPrint);
        }
        //end wall and next row
        change_text_colour(BLUE);
        printf("W\n");
    }
    //prints bottom map cap
    change_text_colour(BLUE);
    printf("W W W W W W W W W W W\n");
}

int numberOfActors(char *map) {
    //scan through to see how many pacman and ghosts
    int numberOfPacman = 0;
    int numberOfGhosts = 0;
    for (int i = 0; i < height * width; i++) {
        if (map[i] == PACMAN) {
            numberOfPacman++;
        } else if (map[i] == GHOST) {
            numberOfGhosts++;
        }
    }
    if (numberOfPacman != 1) {
        return ERR_NO_PACMAN;
    }
    if (numberOfGhosts != 2) {
        return ERR_NO_GHOSTS;
    }
    return NO_ERROR;
}

