// APSC 142 Engineering Programming Project Starter Code
// Copyright Sean Kauffman 2024

#include "defines.h"
#include "game.h"

extern char * map, * dot_map;
extern int height;
extern int width;

int check_win(int pacman_y, int pacman_x, int ghosts_y[NUM_GHOSTS], int ghosts_x[NUM_GHOSTS]) {
    int dotCounter = 0;
    for(int i = 0; i<(width*height+1); i++){
        if(dot_map[i] == DOT){
            dotCounter++;
        }
    }
    if(dotCounter == 0){
        return YOU_WIN;
    }
    return KEEP_GOING;
}

int check_loss(int pacman_y, int pacman_x, int ghosts_y[NUM_GHOSTS], int ghosts_x[NUM_GHOSTS]) {
    for (int i=0; i<NUM_GHOSTS; i++) {
        if ((pacman_x == ghosts_x[i]) && (pacman_y == ghosts_y[i])) {
            return YOU_LOSE;
        }
    }
    return KEEP_GOING;

}


