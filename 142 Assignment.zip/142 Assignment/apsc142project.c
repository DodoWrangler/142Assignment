// APSC 142 Engineering Programming Project Starter Code
// Copyright Sean Kauffman 2024

// don't forget to update your project configuration to select "Emulate terminal in the output console"

// Make sure to include all relevant libraries
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// colours.h contains functions to change text colour and read single characters without requiring an enter
#include "colours.h"
// defines.h contains useful definitions to keep your code readable
#include "defines.h"
// map.h, game.h, and ghost.h contain prototypes of functions you must implement
#include "map.h"
#include "game.h"
#include "ghost.h"

// These global variables must be used to store map information.
// Almost every function needs these variables, so keeping them as globals helps keep things organized.
// map is a pointer to a dynamically allocated map for displaying to the user
// dot_map is a pointer to a dynamically allocated map for keeping track of what dots are left
char *map = NULL, *dot_map = NULL;
// width and height store the width and height of map, NOT counting outer walls
int width, height;



/**
 * Main entry point into your program.
 * Make sure that main returns appropriate status codes depending on what
 * happens.  The codes you must use are:
 *   NO_ERROR when no error occurs
 *   ERR_NO_MAP when no map file is found
 *   ERR_NO_PACMAN when no pacman is found on the map
 *   ERR_NO_GHOSTS when fewer than 2 ghosts are found on the map
 *
 * Make sure that any allocated memory is freed before returning.
 * @return a status code
 */
int main(void) {
    setbuf(stdout, NULL);
    FILE *fp;
    //set during testing to absolute path
    fp = fopen("C:\\Users\\steve\\OneDrive\\Desktop\\142 Assignment\\map.txt", "r");

    if (fp == NULL) {
        return ERR_NO_MAP;
    }

    char *map = (char *) malloc(1 * sizeof(char *));

    int x = 0, y = 0;
    int numberOfPacman = 0, numberOfGhosts = 0;
    int counter = 0;
    //randomly initialized so that nothing breaks
    char temp = 'a';
    width = -1;

    while (1) {
        //check next character, hold at temp variable
        fscanf(fp, "%c", &temp);
        if ((x) == width && temp != '\n') {
            height = (y + 1);
            break;
        } else if (temp == PACMAN) {
            numberOfPacman++;
            counter++;
            realloc(map, counter*sizeof(char));
            map[counter] = temp;
            x++;
        } else if (temp == GHOST) {
            numberOfGhosts++;
            counter++;
            realloc(map, counter*sizeof(char));
            map[counter] = temp;
            x++;
        } else if (temp == DOT || temp == WALL) {
            counter++;
            realloc(map, counter*sizeof(char));
            map[counter] = temp;
            x++;
        } else if (temp == '\n') {
            width = x;
            realloc(map, counter*sizeof(char));
            map[counter] = temp;
            x = 0;
            y++;
        }
    }
    realloc(map, (counter+1)*sizeof(char));
    map[counter+1] = '\0';
    fclose(fp);

    map = load_map("C:\\Users\\steve\\OneDrive\\Desktop\\142 Assignment\\map.txt", &height, &width);
    print_map(map, &height, &width);

    //make sure that there are two ghosts and a pacman
    if (numberOfActors(map) == ERR_NO_GHOSTS) {
        return ERR_NO_GHOSTS;
    }
    if (numberOfActors(map) == ERR_NO_PACMAN) {
        return ERR_NO_PACMAN;
    }

    dot_map = (char *) (char **) malloc(9 * sizeof(char *));
    for (int i = 0; i < (width*height); i++) {
        if (map[i] == GHOST) {
            dot_map[i] = DOT;
        } else if (map[i] == PACMAN) {
            dot_map[i] = EMPTY;
        }else {
            dot_map[i] = map[i];
        }
    }

    while (1) {
        //finds pacman
        int pacman_x, pacman_y;
        for (int i = 0; i < (width*height+1); i++) {
            if (map[i] == PACMAN) {
                pacman_x = i % 9;
                pacman_y = (i - (i % 9)) / 9;
                map[i] = EMPTY;
            }
        }

        //prints pacman coord for debugging
//        printf("%d %d\n", pacman_x, pacman_y);

        //finds ghost(s)
        int ghost1_x, ghost1_y, ghost2_x, ghost2_y;
        //counter to track current ghost
        int counter = 0;
        for (int i = 0; i < (width*height+1); i++) {
            if (counter == 0) {
                if (map[i] == GHOST) {
                    ghost1_x = i % 9;
                    ghost1_y = (i - (i % 9)) / 9;
                    counter++;
                    //change the spot to the dotmap
                    map[i] = dot_map[i];
                }
            } else {
                if (map[i] == GHOST) {
                    ghost2_x = i % 9;
                    ghost2_y = (i - (i % 9)) / 9;
                    //change the spot to the dotmap
                    map[i] = dot_map[i];
                }
            }
        }

        //prints ghost coords for debugging
//        printf("%d %d \n", ghost1_x, ghost1_y);
//        printf("%d %d \n", ghost2_x, ghost2_y);

        //gets user move input

        //sets pointers to updated coords
        int *x = &pacman_x;
        int *y = &pacman_y;

        //make an array to hold the ghost coords
        int ghostXCoords[2]={ghost1_x, ghost2_x};
        int ghostYCoords[2]={ghost1_y, ghost2_y};

        if (check_loss(pacman_y, pacman_x, ghostYCoords, ghostXCoords)==YOU_LOSE){
            printf ("Sorry, you lose.\n");
            return 0;
        }


        while (1) {
            //gets user input in form of a character (key press)
            char input = getch();
            //moves pacman according to input
            int pacmanMovement = move_actor(&pacman_y, &pacman_x, input, 1);//new
            if (pacmanMovement == MOVED_OKAY) {
                map[((*y) * width) + *x] = PACMAN;



                //check if the ghosts see pacman
                if (sees_pacman(pacman_y, pacman_x, ghost1_y, ghost1_x) != SEES_NOTHING) {
                    //move the ghost in the direction of pacman from the function sees_pacman
                    move_actor(&ghost1_y, &ghost1_x, sees_pacman(pacman_y, pacman_x, ghost1_y, ghost1_x), 0);
                } else {
                    //if you cannot see the pacman then go in a random direction
                    int moved = 0;
                    while(moved == 0) {
                        int direc = rand() % 4;
                        //checks that the selected direction is valid. If so, breaks the loop


                        //arbitrarily assigns a direction to each of the potential random numbers (0-3)
                        if (direc == 0) {
                            if(move_actor(&ghost1_y, &ghost1_x, UP, 0) == MOVED_OKAY){
                                moved = 1;
                            }
                            //map[((ghost1_y) * width) + ghost1_x] = GHOST;
                        } else if (direc == 1) {
                            if(move_actor(&ghost1_y, &ghost1_x, DOWN, 0) == MOVED_OKAY){
                                moved = 1;
                            }
                            //map[((ghost1_y) * width) + ghost1_x] = GHOST;
                        } else if (direc == 2) {
                            if(move_actor(&ghost1_y, &ghost1_x, LEFT, 0) == MOVED_OKAY){
                                moved = 1;
                            }
                            //map[((ghost1_y) * width) + ghost1_x] = GHOST;
                        } else if (direc == 3) {
                            if(move_actor(&ghost1_y, &ghost1_x, RIGHT, 0) == MOVED_OKAY){
                                moved = 1;
                            }
                            //map[((ghost1_y) * width) + ghost1_x] = GHOST;
                        }

                    }
                    map[((ghost1_y) * width) + ghost1_x] = GHOST;
                }
                if (sees_pacman(pacman_y, pacman_x, ghost2_y, ghost2_x) != SEES_NOTHING) {
                    //move the ghost in the direction of pacman from the function sees_pacman
                    move_actor(&ghost2_y, &ghost2_x, sees_pacman(pacman_y, pacman_x, ghost2_y, ghost2_x), 0);
                } else {
                    //if you cannot see the pacman then go in a random direction
                    int direc = rand() % 4;
                    //arbitrarily assign a direction to each of the possible outputs
                    if (direc == 0) {
                        move_actor(&ghost2_y, &ghost2_x, UP, 0);
                        //map[((ghost2_y) * width) + ghost2_x] = GHOST;
                    } else if (direc == 1) {
                        move_actor(&ghost2_y, &ghost2_x, DOWN, 0);
                        //map[((ghost2_y) * width) + ghost2_x] = GHOST;
                    } else if (direc == 2) {
                        move_actor(&ghost2_y, &ghost2_x, LEFT, 0);
                        //map[((ghost2_y) * width) + ghost2_x] = GHOST;
                    } else if (direc == 3) {
                        move_actor(&ghost2_y, &ghost2_x, RIGHT, 0);
                        //map[((ghost2_y) * width) + ghost2_x] = GHOST;
                    }
                    map[((ghost2_y) * width) + ghost2_x] = GHOST;
                }

                //put pacman and ghosts on map
                map[((*y) * width) + *x] = PACMAN;
                map[((ghost1_y) * width) + ghost1_x] = GHOST;
                map[((ghost2_y) * width) + ghost2_x] = GHOST;

                //print map BUT ONLY IF MOVE IS CORRECT
                print_map(map, &height, &width);
                //check if win
                if(check_win(pacman_y, pacman_x, ghostYCoords, ghostXCoords) !=KEEP_GOING){
                    if (check_loss(pacman_y, pacman_x, ghostYCoords, ghostXCoords)!= YOU_LOSE){
                        printf("Congratulations! You win!\n");
                        return 0;
                    }
                }
                break;
            }
            break;
        }
    }
    return 0;
}

